from tkinter import *
from PIL import ImageTk, Image
import subprocess

def login():
    root.withdraw()  # Hide the login window
    subprocess.call(["python", "cyberscan.py"])

root = Tk()
root.title("CyberScan - Login")
root.attributes("-zoomed", True)  # Maximize the window

# Set background image
background_image = ImageTk.PhotoImage(file="background_image.jpg")
background_label = Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

logo_image = PhotoImage(file="logo.png").subsample(4)
logo_label = Label(root, image=logo_image)
logo_label.place(relx=0.5, rely=0.1, anchor="center")

container = Frame(root, padx=20, pady=20, highlightthickness=0)
container.place(relx=0.5, rely=0.5, anchor="center")

# Create username label and entry
username_label = Label(root, text="Username:")
username_label.pack()
username_entry = Entry(root)
username_entry.pack()

# Create password label and entry
password_label = Label(root, text="Password:")
password_label.pack()
password_entry = Entry(root, show="*")
password_entry.pack()

# Create login button
login_button = Button(root, text="Login", command=login)
login_button.pack()

root.mainloop()

