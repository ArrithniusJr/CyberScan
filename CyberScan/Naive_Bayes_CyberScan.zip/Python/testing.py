import customtkinter
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import csv
import random
import math

customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("dark-blue")

root = customtkinter.CTk()
root.title("Dashboard | CyberScan - Content Detector")
root.geometry("900x600")
root.resizable(False, False)

# ---------- My own data for practice ---------# 
"""
harmful_content = [
    ("This is a spam message. Click here to unsubscribe.", "harmful detected"),
    ("Buy our products now! They're the best on the market.", "harmful detected"),
    ("You won a prize! Just click here to claim your reward.", "harmful detected"),
    ("I do hate you. You're a worthless piece of shit.", "harmful detected"),
    ("This is a phishing email. Do not click on any links in this message.", "harmful detected"),
    ("This link contains malware. Do not click on it.", "harmful detected"),
    ("This image contains child sexual abuse content.", "harmful detected"),
    ("This video contains violent content.", "harmful detected"),
    ("This text contains hate speech.", "harmful detected"),
    ("This message is threatening or abusive.", "harmful detected"),
    ("This message is about self-harm or suicide.", "harmful detected"),
    ("This image is pornographic.", "harmful detected"),
    ("This video is pornographic.", "harmful detected"),
    ("This text is pornographic.", "harmful detected"),
    ("This message is spam.", "harmful detected",),
    ("This email is spam.", "harmful detected"),
    ("This link is spam.", "harmful detected"),
    ("This image is spam.", "harmful detected"),
    ("This video is spam.", "harmful detected"),
    ("This text is spam.", "harmful detected")
]

non_harmful_content = [
    ("Hello, how are you? I'm doing well, thanks for asking.", "non harmful detected"),
    ("What's for dinner? I'm thinking we could order pizza.", "non harmful detected"),
    ("Let's go to the park. It's a beautiful day outside.", "non harmful detected"),
    ("I do not hate you. I actually think you're pretty cool.", "non harmful detected"),
    ("This is a news article about the latest developments in the COVID-19 pandemic.", "non harmful detected"),
    ("This is an educational video about how to change a tire.", "non harmful detected"),
    ("This is a creative piece of writing about the importance of imagination.", "non harmful detected"),
    ("This is a personal story about my experience with overcoming adversity.", "non harmful detected"),
    ("This is a question and answer forum about the best places to travel in Europe.", "non harmful detected"),
    ("This is a request for help with finding a job.", "non harmful detected"),
    ("This is a technical support forum for help with computer problems.", "non harmful detected"),
    ("This is a general conversation about the latest movies.", "non harmful detected"),
    ("This is a discussion about the best books to read.", "non harmful detected"),
    ("This is a debate about the merits of different political systems.", "non harmful detected"),
    ("This is a chat room for people who are interested in learning about new cultures.", "non harmful detected"),
    ("This is a forum for people who are interested in discussing social justice issues.", "non harmful detected"),
    ("This is a blog about the latest trends in fashion.", "non harmful detected"),
    ("This is a website that provides information about different types of music.", "non harmful detected"),
    ("This is a podcast about the latest news in the tech industry.", "non harmful detected"),
    ("This is a social media platform where people can share their thoughts and ideas.", "non harmful detected")
]
"""
"""
# ---------- Data ---------# 
class_mapping = {
    "0": "Hateful Speech Detected",
    "1": "Offensive Speech Detected",
    "2": "Neither Harmful/Offensive Speech detected",
    "3": "Neither Harmful/Offensive Speech detected"
}
def read_data1(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            label = row['class']
            text = row['tweet']            
            mapped_label = class_mapping[label]
            dataset.append((text, mapped_label))
    return dataset
def read_data2(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            label = row['class']
            text = row['tweet']            
            mapped_label = class_mapping[label]
            dataset.append((text, mapped_label))
    return dataset
    
class_mapping_data3 = {
    "0": "No Harm detected",
    "1": "Hate speech"
}
def read_data3(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            text = row['text']
            label = row['label']
            mapped_label = class_mapping_data3.get(label, 'Unknown')
            dataset.append((text, mapped_label))
    return dataset 
def read_data4(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            text = row['text']
            label = row['label']
            mapped_label = class_mapping.get(label)
            dataset.append((text, mapped_label))
    return dataset
    
# ---------- Reading Files ---------# 
dataset1 = read_data1('data1.csv')
dataset2 = read_data2('data2.csv')
dataset3 = read_data3('data3.csv')
dataset4 = read_data4('data4.csv')
"""
#dataset = dataset1 + dataset2 + dataset3 + dataset4
class_mapping = {
    0: "Hateful Speech Detected",
    1: "Offensive Speech Detected",
    #"2": "Neither Harmful/Offensive Speech detected",
    3: "Neither Harmful/Offensive Speech detected"
}
def read_data1(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            label = int(row['class'])
            text = row['tweet']            
            mapped_label = class_mapping.get(label)
            dataset.append((text, mapped_label))
    return dataset

dataset1 = read_data1('twitter_data.csv')

dataset = dataset1

# ---------- Cleaning all the data ---------# 
def clean_text(text):
    start_idx = 0
    while True:
        start_idx = text.find('http', start_idx)
        if start_idx == -1:
            break
        end_idx = text.find(' ', start_idx)
        if end_idx == -1:
            end_idx = len(text)
        text = text[:start_idx] + ' ' + text[end_idx:]

    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    for char in punctuation:
        text = text.replace(char, '')

    text = text.replace('\n', ' ')

    words = text.split()
    words = [word for word in words if not any(char.isdigit() for char in word)]
    text = ' '.join(words)

    text = text.lower()

    stopwords = set(['the', 'is', 'you', 'our', 'an', 'a', 'this', 'these', 'it', 'on', 'so', 'of', 'all', 'am', 'an', 'and', 'any', 'are', 'as',
    'at', 'be'])
    words = text.split()
    words = [word for word in words if word not in stopwords]

    cleaned_text = ' '.join(words)
    return cleaned_text
    
cleaned_dataset = [(clean_text(text), label) for text, label in dataset]

#DOES RANDOMIZING THIS DATA ALSO SHUFFLE THE LABELS?
# ---------- Randomize all the data ---------#
def data_random(data):
    n = len(data)
    for i in range(n):
        j = random.randint(i, n - 1)
        data[i], data[j] = data[j], data[i]

rand_data = cleaned_dataset.copy()
data_random(rand_data)

train_size = int(0.8 * len(rand_data))
train_data = rand_data[:train_size]
test_data = rand_data[train_size:]

# ---------- Training Vocabulary ---------#
vocabulary = set()
for text, label in train_data:
    words = text.split()
    vocabulary.update(words)

def calculate_class_priors(dataset):
    class_counts = {}  # Count occurrences of each class label
    total_examples = len(dataset)

    for _, label in dataset:
        class_counts[label] = class_counts.get(label, 0) + 1

    class_priors = {}  # Calculate class priors
    for label, count in class_counts.items():
        class_priors[label] = count / total_examples

    return class_priors

# Calculate class priors based on the training data
class_priors = calculate_class_priors(train_data)


def train_naive_bayes(train_data, vocabulary, class_priors):
    # Create a dictionary to store word counts for each class
    class_word_counts = {label: {} for label in class_priors}

    # Initialize word counts to avoid zero probabilities
    for label in class_word_counts:
        for word in vocabulary:
            class_word_counts[label][word] = 1

    # Count occurrences of words for each class
    for text, label in train_data:
        words = text.split()
        for word in words:
            if word in vocabulary:
                class_word_counts[label][word] += 1

    return class_word_counts

# Train the Naive Bayes classifier on the training data
class_word_counts = train_naive_bayes(train_data, vocabulary, class_priors)

def predict_naive_bayes(text, class_word_counts, class_priors, vocabulary):
    words = text.split()
    scores = {}

    for label in class_priors:
        score = math.log(class_priors[label])  # Initialize with class prior probability

        for word in words:
            if word in vocabulary:
                word_count = class_word_counts[label][word]
                total_word_count = sum(class_word_counts[label].values())
                word_prob = word_count / total_word_count
                score += math.log(word_prob)

        scores[label] = score

    # Find the class with the highest score (maximum a posteriori)
    predicted_label = max(scores, key=scores.get)
    return predicted_label

# ---------- Training the Naive Bayes Classifier ---------#
class_count = {}
word_count = {}
for text, label in train_data:
    words = text.split()
    for word in words:
        if label in class_count:
            class_count[label] += 1
        else:
            class_count[label] = 1

        if label not in word_count:
            word_count[label] = {}

        if word in word_count[label]:
            word_count[label][word] += 1
        else:
            word_count[label][word] = 1

# Calculate class priors
class_priors = calculate_class_priors(train_data)
"""
# ---------- TEST: Print Rand Train Data ---------#
print("Randomized Training Dataset:")
for text, label in train_data:
    print(f"Text: {text}, Label: {label}")

# ---------- TEST: Print Rand Test Data ---------#
print("Randomized Testing Dataset:")
for text, label in test_data:
    print(f"Text: {text}, Label: {label}")

# ---------- TEST: Print Cleaned data ---------#
def print_cleaned_dataset(dataset):
    for text, label in dataset:
        print(f"Text: {text}, Label: {label}")

# Print the cleaned dataset
print("Cleaned Dataset:")
print_cleaned_dataset(cleaned_dataset)
"""

# ---------- COLUMN 1 ---------# 
# ---------- Account Frame ---------# 
account_frame = customtkinter.CTkFrame(master=root)
account_frame = customtkinter.CTkFrame(root, width=200, height=600)
account_frame.pack(pady=20, padx=(20, 15), fill="both", expand=True, side="left")

# ---------- Account Description ---------# 
text = "Account"
description_label = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, font=("Liberation Sans", 16, "bold"), anchor="w")
description_label.pack(pady=15, padx=10, fill="x", expand=False)

# ---------- Username Parameter ---------# 
text = "Username"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=40, x=10)

# ---------- Email Parameter ---------# 
text = "Email"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=68, x=10)

# ---------- Log out button ---------# 
def logout():
    canvas_dashboard.destroy()

log_out = customtkinter.CTkButton(master=account_frame, text="Log out", command=logout, cursor='hand2')
log_out.pack(pady=53, padx=10, fill="x")
log_out.configure(height= 40)

# ---------- COLUMN 2 --------- # 
# ---------- Dashboard Frame ---------# 
canvas_dashboard = customtkinter.CTkFrame(master=root)
canvas_dashboard = customtkinter.CTkFrame(root, width=600, height=600)
canvas_dashboard.pack(pady=20, padx=(10, 20), fill="both", expand=True, side="left")

# ---------- Logo ---------# 
light_image = Image.open("logo-no-background.png").convert("RGBA")
dark_image = Image.open("logo-no.png").convert("RGBA")

logo_image = customtkinter.CTkImage(light_image=light_image, dark_image=dark_image, size=(310, 150))
logo_label = customtkinter.CTkLabel(canvas_dashboard, image=logo_image)
logo_label.configure(text="")
logo_label.place(relx=0.5, rely=0.5, anchor="center")
logo_label.pack(pady=20)

# ---------- Container Frame ---------# 
container = customtkinter.CTkFrame(master=canvas_dashboard)
container = customtkinter.CTkFrame(canvas_dashboard, width=300, height=250)
container.pack(pady=0, padx=100, fill="both", expand=True)

# ---------- Description ---------# 
text = "A CyberScan software is a system that lets you test your content to find out if it is harmful or not. Use the below ChatBox to analyse your message before sending."
description_label = customtkinter.CTkLabel(container, text=text, wraplength=390)
description_label.pack(pady="15")

#---------- Separator ---------
style = ttk.Style()
style.configure("Horizontal.TSeparator", background="black") 
line_separator = ttk.Separator(container, orient="horizontal", style="Horizontal.TSeparator")
line_separator.pack(fill="x", padx=50, pady=10)

# ---------- Message ---------# 
def msg_onfocus(e):
    message.delete(0, 'end')

def msg_offfocus(e):
    name=message.get() 
    if name=='':
        message.insert(0, 'Enter your content here')
        message.configure(fg_color='gray')

message_txt = customtkinter.CTkLabel(container, text="Message:")
message_txt.pack()
message = customtkinter.CTkEntry(master=container, placeholder_text="Enter your content here")
message.bind('<FocusIn>', msg_onfocus) 
message.bind('<FocusOut>', msg_offfocus) 
message.pack(pady=2, padx=10)
message.configure(height=40, width=300)


# ---------- Analyze button ---------# 
def analyze_content():
    input_text_value = message.get().strip()  # Get the text from the CTkEntry widget
    if input_text_value:
        cleaned_input = clean_text(input_text_value)
        
        # Calculate likelihoods for the user input
        likelihoods = {}
        for label in class_count:
            likelihood = class_priors[label]
            for word in cleaned_input.split():
                if label in word_count and word in word_count[label]:
                    likelihood *= word_count[label][word] / class_count[label]
            likelihoods[label] = likelihood

        # Predict the label with the highest likelihood
        predicted_label = max(likelihoods, key=likelihoods.get)

        result_container.configure(text="Results: " + predicted_label)
     

analyse_button = customtkinter.CTkButton(master=container, text="Analyse", command=analyze_content, cursor='hand2')
analyse_button.pack(side="left", padx=(130, 10), anchor="center")
analyse_button.configure(height=40)

# ---------- Clear button ---------# 
clear_icon = customtkinter.CTkImage(Image.open("bin.png").convert("RGBA"))

def clear_text():
    message.delete(0, 'end')
    result_container.configure(text="Results: ")

clear_button = customtkinter.CTkButton(master=container, image=clear_icon, command=clear_text, cursor='hand2', fg_color="#990000", hover_color="#660000")
clear_button.configure(height=40, width=15, text="")
clear_button.pack(side="left", padx=(5, 100), anchor="center")

# ---------- Results Frame ---------# 
container2 = customtkinter.CTkFrame(master=canvas_dashboard)
container2 = customtkinter.CTkFrame(canvas_dashboard, width=100, height=100)
container2.pack(pady=15, padx=180, fill="both", expand=False)

# ---------- Result Container ---------# 
result_container = customtkinter.CTkLabel(container2, text="Results: ", wraplength=390)
result_container.pack(pady=15)

root.bind('<Return>', lambda event: analyze_content())

root.mainloop()