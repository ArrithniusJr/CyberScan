import customtkinter
from CTkToolTip import *
from CTkMessagebox import CTkMessagebox
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import csv
import random
import math
from tqdm import tqdm

customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("dark-blue")

root = customtkinter.CTk()
root.title("CyberScan - Content Detector")
root.geometry("900x600")
root.resizable(False, False)

# ---------- Data ---------# 
"""
class_mapping = {
    "Yes": "Offensive Speech Detected",
    "No": "No Offensive Speech Detected"
}
def read_data1(filename):
    dataset = []
    with open(filename, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file, delimiter=';')
        next(reader)   
        for row in reader:
            text = row['Tweets']
            label = row['Label']
            mapped_label = class_mapping[label]
            dataset.append((text, mapped_label))
    return dataset
"""
class_mapping = {
    "0": "No offensive Speech Detected",
    "1": "Offensive Speech Detected"
}
def read_data_data(filename):
    dataset= []
    with open(filename, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)

        next(reader)
        for row in reader:
            text=row['tweet']
            label=row['Toxicity']
            mapped_label=class_mapping[label]
            dataset.append((text, mapped_label))
    return dataset

dataset1 = read_data_data('FinalBalancedDataset.csv')
#dataset2 = read_data1('new2.csv')

dataset = dataset1 

# ---------- Cleaning all the data ---------# 
def clean_text(text):
    start_idx = 0
    while True:
        start_idx = text.find('http', start_idx)
        if start_idx == -1:
            break
        end_idx = text.find(' ', start_idx)
        if end_idx == -1:
            end_idx = len(text)
        text = text[:start_idx] + ' ' + text[end_idx:]

    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    for char in punctuation:
        text = text.replace(char, ' ')

    text = text.replace('\n', ' ')

    words = text.split()
    words = [word for word in words if not any(char.isdigit() for char in word)]
    text = ' '.join(words)

    text = text.lower()
    
    stopwords = set([
    "'d", "'ll", "'re", "'s", "'t", "'ve", "n't", "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "cannot", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from", "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "me", "more", "most", "my", "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so", "some", "such", "than", "their", "theirs", "them", "themselves", "the", "then", "there", "these", "they", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", "yours", "yourself", "yourselves", "de", "del", "di", "y", "corp", "corp.", "co", "llc", "inc", "inc.", "ltd", "ltd.", "llp", "llp.", "plc", "plc.", "&", ",", "-", "'"
    ])

    words = text.split()
    words = [word for word in words if word not in stopwords]

    cleaned_text = ' '.join(words)

    return cleaned_text

cleaned_dataset = [(clean_text(text), label) for text, label in dataset]

# ---------- Randomize all the data ---------#
def data_random(data):
    n = len(data)
    for i in range(n):
        j = random.randint(i, n - 1)
        data[i], data[j] = data[j], data[i]

rand_data = cleaned_dataset.copy()
data_random(rand_data)

train_size = int(0.8 * len(rand_data))
train_data = rand_data[:train_size]
test_data = rand_data[train_size:]
    
# ---------- Tokenization & Vocabulary Building ---------#
def tokenize(text):
    return text.split()

def build_vocab(data):
    vocab = set()
    for text, _ in data:
        words = tokenize(text)
        vocab.update(words)
    return vocab

vocab = build_vocab(train_data)

# ---------- Class Prior Probabilities | Likelihood ---------#
class_counts = {label: sum(1 for _, l in train_data if l == label) for label in class_mapping.values()}
total_train_documents = len(train_data)
class_priors = {label: count / total_train_documents for label, count in class_counts.items()}

# ---------- Word Frequency ---------#
def count_words(data, vocab):
    word_counts = {label: {word: 0 for word in vocab} for label in class_mapping.values()}
    for text, label in data:
        words = tokenize(text)
        for word in words:
            word_counts[label][word] += 1
    return word_counts

word_counts = count_words(train_data, vocab)

# ---------- Laplace Smoothing ---------#
alpha = 1
def apply_laplace_smoothing(word_counts, vocab):
    smoothed_word_counts = {label: {word: count + alpha for word, count in counts.items()} for label, counts in word_counts.items()}
    return smoothed_word_counts

smoothed_word_counts = apply_laplace_smoothing(word_counts, vocab)

"""
# ---------- Calculating Conditional Probabilities ---------#
def calcProbability(smoothed_word_counts, vocab):
        conditional_probs = {label: {word: count / sum(counts.values()) for word, count in counts.items()} for label, counts in smoothed_word_counts.items()}
        return conditional_probs

conditional_probs = calcProbability(smoothed_word_counts, vocab)
"""
def calcProbability(smoothed_word_counts, vocab):
    conditional_probs = {}
    with tqdm(total=len(smoothed_word_counts), desc='Calculating conditional probabilities', unit='class', ncols=80) as pbar:
        for label, counts in smoothed_word_counts.items():
            word_probabilities = {}
            total_word_count = sum(counts.values())
            for word, count in counts.items():
                word_probabilities[word] = count / total_word_count
                pbar.update(1) 
            conditional_probs[label] = word_probabilities
    return conditional_probs

conditional_probs = calcProbability(smoothed_word_counts, vocab)

# ---------- Classifying New Texts ---------#
def classify_text(text, conditional_probs, class_priors):
    words = tokenize(text)
    class_scores = {label: math.log(class_priors[label]) for label in class_mapping.values()}
    
    for label in class_mapping.values():
        for word in words:
            if word in conditional_probs[label]:
                class_scores[label] += math.log(conditional_probs[label][word])
    
    predicted_label = max(class_scores, key=class_scores.get)
    return predicted_label

"""
# ---------- TEST ---------# 
for text, label in test_data:
    predicted_label = classify_text(text, conditional_probs, class_priors)
    print("Actual Label:", label, "| Predicted Label:", predicted_label)
"""

# ---------- COLUMN 1 ---------# 
# ---------- Account Frame ---------# 
account_frame = customtkinter.CTkFrame(master=root)
account_frame = customtkinter.CTkFrame(root, width=200, height=600)
account_frame.pack(pady=20, padx=(20, 15), fill="both", expand=True, side="left")

# ---------- Account Description ---------# 
text = "Account"
description_label = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, font=("Liberation Sans", 16, "bold"), anchor="w")
description_label.pack(pady=15, padx=10, fill="x", expand=False)

# ---------- Username Parameter ---------# 
text = "Username"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=40, x=10)

# ---------- Email Parameter ---------# 
text = "Email"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=68, x=10)

# ---------- Log out button ---------# 
def logout():
    root.destroy()

log_out = customtkinter.CTkButton(master=account_frame, text="Log out", command=logout, cursor='hand2')
log_out.pack(pady=53, padx=10, fill="x")
log_out.configure(height= 40)

# ---------- COLUMN 2 --------- # 
# ---------- Dashboard Frame ---------# 
canvas_dashboard = customtkinter.CTkFrame(master=root)
canvas_dashboard = customtkinter.CTkFrame(root, width=600, height=600)
canvas_dashboard.pack(pady=20, padx=(10, 20), fill="both", expand=True, side="left")

# ---------- Logo ---------# 
light_image = Image.open("logo-no-background.png").convert("RGBA")
dark_image = Image.open("logo-no.png").convert("RGBA")

logo_image = customtkinter.CTkImage(light_image=light_image, dark_image=dark_image, size=(310, 150))
logo_label = customtkinter.CTkLabel(canvas_dashboard, image=logo_image)
logo_label.configure(text="")
logo_label.place(relx=0.5, rely=0.5, anchor="center")
logo_label.pack(pady=20)

# ---------- Container Frame ---------# 
container = customtkinter.CTkFrame(master=canvas_dashboard)
container = customtkinter.CTkFrame(canvas_dashboard, width=300, height=250)
container.pack(pady=0, padx=100, fill="both", expand=True)

# ---------- Description ---------# 
text = "A CyberScan software is a system that lets you test your content to find out if it is harmful or not. Use the below ChatBox to analyse your message before sending."
description_label = customtkinter.CTkLabel(container, text=text, wraplength=390)
description_label.pack(pady="15")

#---------- Separator ---------
style = ttk.Style()
style.configure("Horizontal.TSeparator", background="black") 
line_separator = ttk.Separator(container, orient="horizontal", style="Horizontal.TSeparator")
line_separator.pack(fill="x", padx=50, pady=10)

# ---------- Message ---------# 
def msg_onfocus(e):
    message.delete(0, 'end')

def msg_offfocus(e):
    name=message.get() 
    if name=='':
        message.insert(0, 'Enter your content here')
        message.configure(placeholder_text="Enter your content here")

message_txt = customtkinter.CTkLabel(container, text="Message:")
message_txt.pack()
message = customtkinter.CTkEntry(master=container, placeholder_text="Enter your content here")
message.bind('<FocusIn>', msg_onfocus) 
message.bind('<FocusOut>', msg_offfocus) 
message.pack(pady=2, padx=10)
message.configure(height=40, width=300)

def analyze_content():
    input_text_value = message.get().strip()
    if input_text_value:
        predicted_label = classify_text(input_text_value, conditional_probs, class_priors)
        new_icon_label = show_info_icon(info_img) 
        if hasattr(analyze_content, "icon_label"):
            analyze_content.icon_label.pack_forget()
        
        result_container.configure(text="Results: " + predicted_label)
        result_container.pack(side="left", padx=0)
        new_icon_label.pack(side="left", padx=14)
        
        analyze_content.icon_label = new_icon_label
        new_icon_label.bind("<Button-1>", lambda event: explanation_box(input_text_value, predicted_label))

def explanation_box(input_text_value, predicted_label):
    explanation = generate_tooltip_message(input_text_value, predicted_label)
    msg = CTkMessagebox(width=500, title="Why " + predicted_label + "?", cancel_button="circle", message=explanation, icon="question.png", option_1="Ok")

def generate_tooltip_message(input_text, predicted_label):
    explanation = ""
    words = tokenize(input_text)
    for word in words:
        explanation += f"'{word}':\n"
        for label in class_mapping.values():
            if label == "Offensive Speech Detected":
                newLab = "Offensive"   
            else:
                newLab = "Not Offensive"
                
            prob = conditional_probs[label].get(word, 0)
            if prob != 0.000:
                explanation += f"  P({newLab} | {word}) = {prob:.4f}\n"

    explanation += f"\nFINAL RESULTS:\n"
    for label, prior in class_priors.items():
        if label == "Offensive Speech Detected":
            newLab = "Offensive" 
            explanation += f"  P({newLab}) = {prior:.4f}\n"
        else:
            newLab = "Not Offensive"
            explanation += f"  P({newLab}) = {prior:.4f}\n"

    explanation += f"\nThus " + predicted_label + "."

    return explanation

analyse_button = customtkinter.CTkButton(master=container, text="Analyse", command=analyze_content, cursor='hand2')
analyse_button.pack(side="left", padx=(130, 10), anchor="center")
analyse_button.configure(height=40)

# ---------- Clear button ---------# 
clear_icon = customtkinter.CTkImage(Image.open("bin.png").convert("RGBA"))

def clear_text():
    message.delete(0, 'end')
    result_container.configure(text="Results: ")
    analyze_content.icon_label.pack_forget()

clear_button = customtkinter.CTkButton(master=container, image=clear_icon, command=clear_text, cursor='hand2', fg_color="#990000", hover_color="#660000")
clear_button.configure(height=40, width=15, text="")
clear_button.pack(side="left", padx=(5, 100), anchor="center")

# ---------- Results Frame | Container2 ---------# 
container2 = customtkinter.CTkFrame(master=canvas_dashboard)
container2.pack(pady=15, padx=180, fill="both", expand=False)

# ---------- Result Container ---------# 
result_container = customtkinter.CTkLabel(master=container2, text="Results: ", wraplength=390)
result_container.pack(pady=15, padx=0, fill="both", expand=True)

def create_info_image():
    info_icon_light = Image.open("info.png").convert("RGBA")
    info_icon_dark = Image.open("info.png").convert("RGBA")
    info_img = customtkinter.CTkImage(light_image=info_icon_light, dark_image=info_icon_dark, size=(15, 15))
    return info_img

def show_info_icon(info_img):
    info_label = customtkinter.CTkLabel(container2, image=info_img, cursor="hand2")
    info_label.configure(text="")
    info_label.pack(side="left", padx=0)
    return info_label

info_img = create_info_image()

root.bind('<Return>', lambda event: analyze_content())

root.mainloop()