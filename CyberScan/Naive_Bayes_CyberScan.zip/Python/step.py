import customtkinter
from CTkToolTip import *
from CTkMessagebox import CTkMessagebox
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import csv
import random
import math
from tqdm import tqdm

customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("dark-blue")

root = customtkinter.CTk()
root.title("CyberScan - Content Detector")
root.geometry("900x600")
root.resizable(False, False)

# ---------- Data ---------# 
class_mapping = {
    "0": "No Offensive Speech Detected",
    "1": "Offensive Speech Detected"
}

def read_data(filename):    
    dataset= []
    with open(filename, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)

        next(reader)
        for row in reader:
            text=row['tweet']
            label=row['Toxicity']
            mapped_label=class_mapping[label]
            dataset.append((text, mapped_label))
    return dataset

dataset = read_data('FinalBalancedDataset.csv')

# ---------- Cleaning all the data ---------# 
def clean_text(text):
    start_idx = 0
    while True:
        start_idx = text.find('http', start_idx)
        if start_idx == -1:
            break
        end_idx = text.find(' ', start_idx)
        if end_idx == -1:
            end_idx = len(text)
        text = text[:start_idx] + ' ' + text[end_idx:]

    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    for char in punctuation:
        text = text.replace(char, ' ')

    text = text.replace('\n', ' ')

    words = text.split()
    words = [word for word in words if not any(char.isdigit() for char in word)]
    text = ' '.join(words)

    text = text.lower()
    """
    stopwords = set([
    "'d", "'ll", "'re", "'s", "'t", "'ve", "n't", "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "cannot", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from", "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "me", "more", "most", "my", "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so", "some", "such", "than", "their", "theirs", "them", "themselves", "the", "then", "there", "these", "they", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", "yours", "yourself", "yourselves", "de", "del", "di", "y", "corp", "corp.", "co", "llc", "inc", "inc.", "ltd", "ltd.", "llp", "llp.", "plc", "plc.", "&", ",", "-", "'"
    ])"""

    stopwords = set([])
    words = text.split()
    words = [word for word in words if word not in stopwords]

    cleaned_text = ' '.join(words)

    return cleaned_text

cleaned_dataset = [(clean_text(text), label) for text, label in dataset]

# ---------- Randomize all the data ---------#
def data_random(data):
    n = len(data)
    for i in range(n):
        j = random.randint(i, n - 1)
        data[i], data[j] = data[j], data[i]

rand_data = cleaned_dataset.copy()
data_random(rand_data)

train_size = int(0.8 * len(rand_data))
train_data = rand_data[:train_size]
test_data = rand_data[train_size:]
    
# ---------- Tokenization & Vocabulary Building ---------#
def tokenize(text):
    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    words = []
    word = ""
    for char in text:
        char = char.lower()
        if char.isalpha() or char.isdigit():
            word += char
        elif char in punctuation or char.isspace():
            if word:
                words.append(word)
            if char != ' ':
                words.append(char)
            word = ""
    if word:
        words.append(word)
    return words

tokenized_train_data = [(tokenize(text), label) for text, label in train_data]

def build_vocab(data):
    vocab = []
    for text, _ in data:
        words = tokenize(text)
        vocab.extend(words)
    return list(set(vocab))

vocab = build_vocab(train_data)
"""
def create_document_term_matrix(tokenized_data, vocab):
    matrix = []
    for tokens in tokenized_data:
        word_count = {word: 0 for word in vocab}
        for word in tokens:
            if word in vocab:
                word_count[word] += 1
        matrix.append(list(word_count.values()))
    return matrix

X_train = create_document_term_matrix([tokens for tokens, _ in tokenized_train_data], vocab)
"""
total_documents = len(train_data)
num_off = sum(label == "Offensive Speech Detected" for _, label in train_data)
num_not_off = total_documents - num_off

prior_off = num_off / total_documents
prior_not_off = num_not_off / total_documents

def calculate_word_probabilities(data, vocab):
    word_probs_off = {word: 0 for word in vocab}
    word_probs_not_off = {word: 0 for word in vocab}
    
    total_words_off = 0
    total_words_not_off = 0
    
    for text, label in data:
        words = tokenize(text)
        if label == "Offensive Speech Detected":
            total_words_off += len(words)
            for word in words:
                word_probs_off[word] += 1
        else:
            total_words_not_off += len(words)
            for word in words:
                word_probs_not_off[word] += 1
    
    for word in vocab:
        word_probs_off[word] = (word_probs_off[word] + 1) / (total_words_off + len(vocab))
        word_probs_not_off[word] = (word_probs_not_off[word] + 1) / (total_words_not_off + len(vocab))
    
    return word_probs_off, word_probs_not_off

word_probs_off, word_probs_not_off = calculate_word_probabilities(train_data, vocab)

def predict_class(input_text, vocab, word_probs_off, word_probs_not_off, prior_off, prior_not_off):
    words = input_text.split()
    log_likelihood_off = 0
    log_likelihood_not_off = 0
    
    for word in words:
        if word in vocab:
            log_likelihood_off += math.log(word_probs_off[word])
            log_likelihood_not_off += math.log(word_probs_not_off[word])
    
    log_likelihood_off += math.log(prior_off)
    log_likelihood_not_off += math.log(prior_not_off)
    
    if log_likelihood_off > log_likelihood_not_off:
        return "Offensive Speech Detected"
    elif log_likelihood_off < log_likelihood_not_off:
        return "No Offensive Speech Detected"
    #else:
    #    return "No Offensive Speech Detected"

def calculate_classification_report(predictions, true_labels):
    class_metrics = {}
    
    classes = set(true_labels)
    total_true = sum(1 for true in true_labels if true == "Offensive Speech Detected")
    total_false = len(true_labels) - total_true
    
    for cls in classes:
        true_positive = 0
        true_negative = 0
        false_positive = 0
        false_negative = 0
        for pred, true in zip(predictions, true_labels):
            if pred == cls and true == cls:
                true_positive += 1
            elif pred == cls and true != cls:
                false_positive += 1
            elif pred != cls and true == cls:
                false_negative += 1
            else:
                true_negative += 1
        
        precision = true_positive / (true_positive + false_positive) if true_positive + false_positive > 0 else 0
        
        recall = true_positive / (true_positive + false_negative) if true_positive + false_negative > 0 else 0
        
        f1_score = 2 * ((precision * recall) / (precision + recall)) if precision + recall > 0 else 0
        
        #total_accuracy = (true_positive + true_negative) / (true_negative + true_positive + false_negative + false_positive)
        total_accuracy = sum(1 for pred, true in zip(predictions, true_labels) if pred == true) / len(true_labels)

        class_metrics[cls] = {
            "precision": precision,
            "recall": recall,
            "f1_score": f1_score,
            "true_positive": true_positive,
            "true_negative": true_negative,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "total_accuracy" : total_accuracy
        }

    return class_metrics, total_true, total_false, total_accuracy

# ---------- COLUMN 1 ---------# 
# ---------- Account Frame ---------# 
account_frame = customtkinter.CTkFrame(master=root)
account_frame = customtkinter.CTkFrame(root, width=200, height=600)
account_frame.pack(pady=20, padx=(20, 15), fill="both", expand=True, side="left")

# ---------- Account Description ---------# 
text = "Account"
description_label = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, font=("Liberation Sans", 16, "bold"), anchor="w")
description_label.pack(pady=15, padx=10, fill="x", expand=False)

# ---------- Username Parameter ---------# 
text = "Username"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=40, x=10)

# ---------- Email Parameter ---------# 
text = "Email"
username_name = customtkinter.CTkLabel(account_frame, text=text, wraplength=190, anchor="w")
username_name.pack(padx=10, fill="x")
username_name.place(y=68, x=10)

# ---------- Log out button ---------# 
def logout():
    root.destroy()

log_out = customtkinter.CTkButton(master=account_frame, text="Log out", command=logout, cursor='hand2')
log_out.pack(pady=53, padx=10, fill="x")
log_out.configure(height= 40)

# ---------- COLUMN 2 --------- # 
# ---------- Dashboard Frame ---------# 
canvas_dashboard = customtkinter.CTkFrame(master=root)
canvas_dashboard = customtkinter.CTkFrame(root, width=600, height=600)
canvas_dashboard.pack(pady=20, padx=(10, 20), fill="both", expand=True, side="left")

# ---------- Logo ---------# 
light_image = Image.open("logo-no-background.png").convert("RGBA")
dark_image = Image.open("logo-no.png").convert("RGBA")

logo_image = customtkinter.CTkImage(light_image=light_image, dark_image=dark_image, size=(310, 150))
logo_label = customtkinter.CTkLabel(canvas_dashboard, image=logo_image)
logo_label.configure(text="")
logo_label.place(relx=0.5, rely=0.5, anchor="center")
logo_label.pack(pady=20)

# ---------- Container Frame ---------# 
container = customtkinter.CTkFrame(master=canvas_dashboard)
container = customtkinter.CTkFrame(canvas_dashboard, width=300, height=250)
container.pack(pady=0, padx=100, fill="both", expand=True)

# ---------- Description ---------# 
text = "A CyberScan software is a system that lets you test your content to find out if it is harmful or not. Use the below ChatBox to analyse your message before sending."
description_label = customtkinter.CTkLabel(container, text=text, wraplength=390)
description_label.pack(pady="15")

#---------- Separator ---------
style = ttk.Style()
style.configure("Horizontal.TSeparator", background="black") 
line_separator = ttk.Separator(container, orient="horizontal", style="Horizontal.TSeparator")
line_separator.pack(fill="x", padx=50, pady=10)

# ---------- Message ---------# 
def msg_onfocus(e):
    message.delete(0, 'end')

def msg_offfocus(e):
    name=message.get() 
    if name=='':
        message.insert(0, 'Enter your content here')
        message.configure(placeholder_text="Enter your content here")

message_txt = customtkinter.CTkLabel(container, text="Message:")
message_txt.pack()
message = customtkinter.CTkEntry(master=container, placeholder_text="Enter your content here")
message.bind('<FocusIn>', msg_onfocus) 
message.bind('<FocusOut>', msg_offfocus) 
message.pack(pady=2, padx=10)
message.configure(height=40, width=300)

def analyze_content():
    input_text_value = message.get().strip()
    if input_text_value:
        predicted_class = predict_class(input_text_value, vocab, word_probs_off, word_probs_not_off, prior_off, prior_not_off)
        true_labels = [predicted_class]

        new_icon_label = show_info_icon(info_img) 
        if hasattr(analyze_content, "icon_label"):
            analyze_content.icon_label.pack_forget()
        
        result_container.configure(text="Results: " + predicted_class)
        result_container.pack(side="left", padx=0)
        new_icon_label.pack(side="left", padx=14)
  
        # ---------- Report Metrics ---------#
        class_metrics, total_true, total_false, total_accuracy = calculate_classification_report([predicted_class], true_labels)

        precision = class_metrics[predicted_class]['precision']
        recall = class_metrics[predicted_class]['recall']
        f1_score = class_metrics[predicted_class]['f1_score']
        true_positive = class_metrics[predicted_class]['true_positive']
        true_negative = class_metrics[predicted_class]['true_negative']
        false_positive = class_metrics[predicted_class]['false_positive']
        false_negative = class_metrics[predicted_class]['false_negative']
        total_accuracy = class_metrics[predicted_class]['total_accuracy']
        
        explanation = generate_tooltip_message(
            input_text_value, predicted_class, precision, recall, f1_score,
            true_positive, true_negative, false_positive, false_negative, total_accuracy, word_probs_off,
            word_probs_not_off
        )

        analyze_content.icon_label = new_icon_label
        new_icon_label.bind("<Button-1>", lambda event: explanation_box(input_text_value, predicted_class, explanation))

def explanation_box(input_text_value, predicted_class, explanation):
    lines = explanation.split("\n")
    max_line_length = max(len(line) for line in lines)
    msg_width = max_line_length * 8 
    
    msg = CTkMessagebox(title=f"Why {predicted_class}?", cancel_button="circle", message=explanation, icon="question.png", option_1="Ok", width=msg_width)


def generate_tooltip_message(input_text, predicted_class, precision, recall, f1_score, true_positive, true_negative, false_positive, false_negative, total_accuracy, word_probs_off, word_probs_not_off):
    words = tokenize(input_text)
    
    explanation = f"Your input: {words}\n\n"
    explanation += f"Precision: {precision:.2f}\n"
    explanation += f"Recall: {recall:.2f}\n"
    explanation += f"F1-Score: {f1_score:.2f}\n"
    explanation += f"True Positive: {true_positive}\n"
    explanation += f"True Negative: {true_negative}\n"
    explanation += f"False Positive: {false_positive}\n"
    explanation += f"False Negative: {false_negative}\n"
    explanation += f"Total Accuracy: {total_accuracy}\n\n"
    
    explanation += "Conditional Probabilities:\n"
    total_prob_off = 0.0
    total_prob_not_off = 0.0

    for word in words:
        word_lower = word.lower() 
        prob_off = word_probs_off.get(word_lower, 0)
        prob_not_off = word_probs_not_off.get(word_lower, 0)

        label_off = class_mapping["1"]
        label_not_off = class_mapping["0"]
        
        print(f"P('{word}')| {label_off}: {prob_off:.4f}\n")
        print(f"P('{word}')| {label_not_off}: {prob_not_off:.4f}\n")

        total_prob_off += prob_off
        total_prob_not_off += prob_not_off

    explanation += f"P('{input_text}' | Offensive Speech) = {total_prob_off:.4f}\n"
    explanation += f"P('{input_text}' | No Offensive Speech) = {total_prob_not_off:.4f}"

    if predicted_class == "Offensive Speech Detected":
        new_predicted_class = "Offensive"
    else:
        new_predicted_class = "Not Offensive"

    explanation += f"\n\nHence, the predicted speech is {new_predicted_class}."

    return explanation

analyse_button = customtkinter.CTkButton(master=container, text="Analyse", command=analyze_content, cursor='hand2')
analyse_button.pack(side="left", padx=(130, 10), anchor="center")
analyse_button.configure(height=40)

# ---------- Clear button ---------# 
clear_icon = customtkinter.CTkImage(Image.open("bin.png").convert("RGBA"))

def clear_text():
    message.delete(0, 'end')
    result_container.configure(text="Results: ")
    analyze_content.icon_label.pack_forget()

clear_button = customtkinter.CTkButton(master=container, image=clear_icon, command=clear_text, cursor='hand2', fg_color="#990000", hover_color="#660000")
clear_button.configure(height=40, width=15, text="")
clear_button.pack(side="left", padx=(5, 100), anchor="center")

# ---------- Results Frame | Container2 ---------# 
container2 = customtkinter.CTkFrame(master=canvas_dashboard)
container2.pack(pady=15, padx=180, fill="both", expand=False)

# ---------- Result Container ---------# 
result_container = customtkinter.CTkLabel(master=container2, text="Results: ", wraplength=390)
result_container.pack(pady=15, padx=0, fill="both", expand=True)

def create_info_image():
    info_icon_light = Image.open("info.png").convert("RGBA")
    info_icon_dark = Image.open("info.png").convert("RGBA")
    info_img = customtkinter.CTkImage(light_image=info_icon_light, dark_image=info_icon_dark, size=(15, 15))
    return info_img

def show_info_icon(info_img):
    info_label = customtkinter.CTkLabel(container2, image=info_img, cursor="hand2")
    info_label.configure(text="")
    info_label.pack(side="left", padx=0)
    return info_label

info_img = create_info_image()

root.bind('<Return>', lambda event: analyze_content())

root.mainloop()